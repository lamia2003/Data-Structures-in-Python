"""
-------------------------------------------------------
t01
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-03-05"
-------------------------------------------------------
"""
# Imports
from List_linked import List

# is_identical
print("is_identical")
other = List()
lst = List()
b = lst.is_identical_r(other)
print(b)
print()

# split_alt
print("split_alt")
even, odd = lst.split_alt()
for i in even:
    print(i)
for i in odd:
    print(i)
print()

# intersection
print("intersection")
source1 = List()
source2 = List()
target = List()
target.intersection(source1, source2)
for i in target:
    print(i)
print()

#
