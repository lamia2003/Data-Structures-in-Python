"""
-------------------------------------------------------
t05
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-19"
-------------------------------------------------------
"""
# Import
from Food_utilities import read_foods, food_search

# Input
fv = open("foods.txt", "r")
foods = read_foods(fv)
fv.close()

# Function Call
results = food_search(foods, 3, 138, True)

# Output
for food in results:
    print(food)
