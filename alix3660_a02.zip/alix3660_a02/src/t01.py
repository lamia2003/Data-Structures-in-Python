"""
-------------------------------------------------------
t01
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-18"
-------------------------------------------------------
"""
# Imports
from Food import Food
from Food_utilities import read_foods, by_origin

# Input
fv = open("foods.txt", "r")
foods = read_foods(fv)
fv.close()
print(Food.origins())
origin = int(input(f"Enter origin number: "))

# Function Call
origins = by_origin(foods, origin)

# Output
print()
for food in origins:
    print(food)
