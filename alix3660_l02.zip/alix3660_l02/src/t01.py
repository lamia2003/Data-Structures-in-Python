"""
-------------------------------------------------------
t01
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-21"
-------------------------------------------------------
"""
# Import
from Stack_array import Stack

# Input
s = Stack()

# Function Call
b = s.is_empty()

# Output
if b is True:
    print(f"Stack is empty, {b}")
else:
    print(f"Stack contains data, {b}")
