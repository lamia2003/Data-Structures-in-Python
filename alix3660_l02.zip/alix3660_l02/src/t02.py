"""
-------------------------------------------------------
t01
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-21"
-------------------------------------------------------
"""
# Imports
from Stack_array import Stack

# Input
s = Stack()
value = input("Enter a data element: ")

# Function Call
s.push(value)

# Output
for value in s:
    print(value)
