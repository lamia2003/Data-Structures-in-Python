"""
-------------------------------------------------------
t06
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-22"
-------------------------------------------------------
"""
# Imports
from Stack_array import Stack
from utilities import array_to_stack, stack_to_array

# Input
stack = Stack()
source = [1, 2, 3]

# Function Call
array_to_stack(stack, source)

# Input
print("Stack:")
for i in stack:
    print(i)
target = []

# Function Call
stack_to_array(stack, target)

# Output
print()
print(f"Target: {target}")
