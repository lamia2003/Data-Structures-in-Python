"""
-------------------------------------------------------
t05
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-22"
-------------------------------------------------------
"""
# Imports
from Stack_array import Stack
from utilities import array_to_stack

# Input
stack = Stack()
source = [1, 2, 3]
print(f"Source: {source}")
print()

# Function Call
array_to_stack(stack, source)

# Output
print("Stack:")
for i in stack:
    print(i)
print()
print(f"Updated source: {source}")
