"""
-------------------------------------------------------
t03
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-21"
-------------------------------------------------------
"""
# Imports
from Stack_array import Stack

# Input
s = Stack()

# Function Call
value = s.pop()

# Output
print(f"Last item in stack: {(value)}")
