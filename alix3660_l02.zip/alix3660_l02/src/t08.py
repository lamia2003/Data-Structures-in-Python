"""
-------------------------------------------------------
t08
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-22"
-------------------------------------------------------
"""
# Imports
from utilities import stack_test

# Input
source = open("foods.txt", "r")

# Function Call
stack_test(source)
