"""
-------------------------------------------------------
t01
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-03-19"
-------------------------------------------------------
"""
# Imports
from Food_utilities import get_food
from functions import hash_table

one = get_food()
print()
two = get_food()
print()
hash_table(4, [one, two])
