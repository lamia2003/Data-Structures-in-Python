"""
-------------------------------------------------------
t01
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-02-03"
-------------------------------------------------------
"""
# Imports
from utilities import array_to_list

# Input
source = [11, 22, 33, 44]
llist = []

# function call
array_to_list(llist, source)

# Output
print(llist)
print(f"Old array: {source}")
