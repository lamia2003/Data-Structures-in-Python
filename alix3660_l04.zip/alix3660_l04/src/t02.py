"""
-------------------------------------------------------
t01
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-02-03"
-------------------------------------------------------
"""
# Imports
from utilities import list_to_array

# Input
llist = [11, 22, 33, 44]
target = []

# function call
list_to_array(llist, target)

# Output
print(target)
print(f"Old list: {llist}")
