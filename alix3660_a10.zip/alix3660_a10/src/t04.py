"""
-------------------------------------------------------
t04
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-04-01"
-------------------------------------------------------
"""
# Imports
from Sorts_Deque_linked import Sorts
from Deque_linked import Deque

random = [1, 20, 10, 12, 43]
a = Deque()
for i in random:
    a.insert_rear(i)

Sorts.gnome_sort(a)

for i in a:
    print(i)
