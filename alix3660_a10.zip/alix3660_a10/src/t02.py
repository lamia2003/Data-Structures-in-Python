"""
-------------------------------------------------------
t02
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-04-01"
-------------------------------------------------------
"""
# Imports
from Sorts_List_linked import Sorts
from List_linked import List

random = [1, 20, 10, 12, 43]
a = List()
for i in random:
    a.append(i)

Sorts.radix_sort(a)

for i in a:
    print(i)
