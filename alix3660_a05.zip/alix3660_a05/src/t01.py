"""
-------------------------------------------------------
t01
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-02-12"
-------------------------------------------------------
"""
# Imports
from List_array import List
from Food import Food
from Food_utilities import read_food, read_foods
from utilities import array_to_list

# Make List
file = open("food.txt", "r")
foods = read_foods(file)
file.close()
source = List()
array_to_list(source, foods)

# append
value = Food("Gulab Jamun", 2, True, 300)
source.append(value)
print("Source:")
for i in source:
    print(i)

# clean
source.clean()
print()
print("Source:")
for i in source:
    print(i)

# combine
source1 = [read_food("Pizza|7|True|150"), read_food("Natto|6|True|212")]
source2 = [read_food("Pizza|7|True|150"), read_food("Natto|6|True|212")]
source.combine(source1, source2)
print()
print("Target:")
for i in source:
    print(i)

# getitem
i = 1
value = source[i]
print()
print(f"Value:")
print(value)

# intersection
source1 = [read_food("Pizza|7|True|150"), read_food("Natto|6|True|212")]
source2 = [read_food("Pizza|7|True|150"), read_food("Natto|6|True|212")]
source.intersection(source1, source2)
print()
print("Target:")
for i in source:
    print(i)

# is_identical
target = []
b = source.is_identical(target)
print()
print(b)

# prepend
value = read_food("Pizza|7|True|150")
source.prepend(value)
print()
print("Source:")
for i in source:
    print(i)

# remove_front
value = source.remove_front()
print()
print("Source:")
for i in source:
    print(i)
print(f"Value:")
print(value)

# remove_many
key = read_food("Pizza|7|True|150")
source.remove_many(key)
print()
print("Source:")
for i in source:
    print(i)

# split
target1, target2 = source.split()
print()
print("target1:")
for i in target1:
    print(i)
print("target2:")
for i in target2:
    print(i)
print("Source:")
for i in source:
    print(i)

# split_alt
source.insert(0, read_food("Butter Chicken|2|False|490"))
source.insert(1, read_food("Gulab Jamun|2|False|490"))
source.insert(2, read_food("Lasagna|7|False|135"))
source.insert(3, read_food("Natto|6|True|212"))
target1, target2 = source.split_alt()
print()
print("target1:")
for i in target1:
    print(i)
print("target2:")
for i in target2:
    print(i)
print("Source:")
for i in source:
    print(i)

# union
source1 = [read_food("Pizza|7|True|150"), read_food("Natto|6|True|212")]
source2 = [read_food("Pizza|7|True|150"), read_food("Natto|6|True|212")]
source.union(source1, source2)
print()
print("Target:")
for i in source:
    print(i)
