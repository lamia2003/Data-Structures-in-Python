"""
-------------------------------------------------------
t02
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-02-12"
-------------------------------------------------------
"""
# Imports
from Sorted_List_array import Sorted_List

# Make List
source = Sorted_List()
source.insert("Butter Chicken|2|False|490")
source.insert("Gulab Jamun|2|False|490")
source.insert("Lasagna|7|False|135")
source.insert("Natto|6|True|212")
source.insert("Natto|6|True|212")

# clean
source.clean()
print("Source:")
for i in source:
    print(i)
print()

# contains
key = ("Natto|6|True|212")
b = key in source
print(b)
print()

# count
key = ("Natto|6|True|212")
n = source.count(key)
print(n)
print()

# find
key = ("Natto|6|True|212")
value = source.find(key)
print(f"Value: {value}")
print()

# __getitem__
i = 1
value = source[i]
print(f"Value: {value}")
print()

# index
key = ("Natto|6|True|212")
n = source.index(key)
print(f"n: {n}")
print()

# intersection
source1 = [("Pizza|7|True|150"), ("Natto|6|True|212")]
source2 = [("Pizza|7|True|150"), ("Natto|6|True|212")]
source.intersection(source1, source2)
print("Target:")
for i in source:
    print(i)

# is_identical
target = [("Pizza|7|True|150"), ("Natto|6|True|212")]
b = source.is_identical(target)
print()
print(f"identical:{b}")

# max
value = source.max()
print()
print(f"Value: {value}")

# min
value = source.min()
print()
print(f"Value: {value}")

# peek
value = source.peek()
print()
print(f"Value: {value}")

# remove
key = ("Natto|6|True|212")
value = source.remove(key)
print()
print(f"Value: {value}")

# remove_front
source = Sorted_List()
source.insert(1)
source.insert(2)
source.insert(3)
source.insert(4)
value = source.remove_front()
print()
print(f"Value: {value}")

# remove_many
key = (2)
value = source.remove_many(key)
print()
print("Source:")
for i in source:
    print(i)

# split
target1, target2 = source.split()
print()
print("Target1:")
for i in target1:
    print(i)
print("Target2:")
for i in target2:
    print(i)

# split_alt
target1, target2 = source.split_alt()
print()
print("Target1:")
for i in target1:
    print(i)
print("Target2:")
for i in target2:
    print(i)

# split_key
source = Sorted_List()
source.insert(1)
source.insert(2)
source.insert(3)
source.insert(4)
key = 2
target1, target2 = source.split_key(key)
print()
print("Target1:")
for i in target1:
    print(i)
print("Target2:")
for i in target2:
    print(i)

# union
source = Sorted_List()
source1 = [1, 2, 3]
source2 = [4, 5, 6]
source.union(source1, source2)
print()
print("source:")
for i in target:
    print(i)
