"""
-------------------------------------------------------
t04
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-15"
-------------------------------------------------------
"""
# Imports
from Food_utilities import read_food

# Input
line = input("Enter info: ")

# Function Call
f = read_food(line)

# Output
print()
print(f)
