"""
-------------------------------------------------------
t02
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-15"
-------------------------------------------------------
"""
# Imports
from Food import Food

# Input
f = Food("Ravioli", 7, False, 246)

# Function Call
s = str(f)

# Output
print(f)
