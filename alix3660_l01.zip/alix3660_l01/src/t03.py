"""
-------------------------------------------------------
t03
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-15"
-------------------------------------------------------
"""
# Import
from Food_utilities import get_food

# Function Call
f = get_food()

# Output
print()
print(f)
