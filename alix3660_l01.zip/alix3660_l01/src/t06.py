"""
-------------------------------------------------------
t06
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-15"
-------------------------------------------------------
"""
# Imports
from Food_utilities import read_food, write_foods

# Input
lasagna = read_food("Lasagna|7|False|135")
butter = read_food("Butter Chicken|2|False|490")
file_variable = open("new_foods.txt", "w")

# Function Call
write_foods(file_variable, [lasagna, butter])

file_variable.close()
