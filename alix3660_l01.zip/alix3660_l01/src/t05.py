"""
-------------------------------------------------------
t06
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-15"
-------------------------------------------------------
"""
# Imports
from Food_utilities import read_foods

# Input
file_variable = open("foods.txt", "r")

# Function Call
foods = read_foods(file_variable)

# Output
for food in foods:
    print(food)
    print()
