"""
-------------------------------------------------------
t03
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-03-18"
-------------------------------------------------------
"""
# Imports
from BST_linked import BST
from Letter import Letter
from functions import do_comparisons, letter_table

DATA1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
bst = BST()
for i in DATA1:
    letter = Letter(i)
    bst.insert(letter)

file = open("gibbon.txt", "rt")
do_comparisons(file, bst)
letter_table(bst)
file.close()
