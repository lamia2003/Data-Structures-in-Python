"""
-------------------------------------------------------
t02
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-03-18"
-------------------------------------------------------
"""
# Imports
from BST_linked import BST
from Letter import Letter
from functions import do_comparisons, comparison_total

# Initializing BSTs
DATA1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
DATA2 = "MFTCJPWADHKNRUYBEIGLOQSVXZ"
DATA3 = "ETAOINSHRDLUCMPFYWGBVKJXZQ"

one = BST()
two = BST()
three = BST()

for i in DATA1:
    letter = Letter(i)
    one.insert(letter)

for i in DATA2:
    letter = Letter(i)
    two.insert(letter)

for i in DATA3:
    letter = Letter(i)
    three.insert(letter)

# t02
file = open("gibbon.txt", "rt")
do_comparisons(file, one)
total = comparison_total(one)
file.close()
print(f"Comparing by order: {DATA1}")
print(f"Total Comparisons:  {total:,}")

file = open("gibbon.txt", "rt")
do_comparisons(file, two)
total = comparison_total(two)
file.close()
print(f"Comparing by order: {DATA2}")
print(f"Total Comparisons:  {total:,}")

file = open("gibbon.txt", "rt")
do_comparisons(file, three)
total = comparison_total(three)
file.close()
print(f"Comparing by order: {DATA3}")
print(f"Total Comparisons:  {total:,}")
