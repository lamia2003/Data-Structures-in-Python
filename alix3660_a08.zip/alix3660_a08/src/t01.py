"""
-------------------------------------------------------
t01
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-03-18"
-------------------------------------------------------
"""
# Imports
from BST_linked import BST

# Initialize BST
bst = BST()
bst.insert(1)
bst.insert(2)
bst.insert(3)
bst.insert(4)

# is_balanced
print("is_balanced")
b = bst.is_balanced()
print(b)
print()

# is_valid
print("is_valid")
b = bst.is_valid()
print(b)
print()

# is_identical
print("is_identical")
other = BST()
b = bst.is_identical(other)
print(b)
print()

# min
print("min")
value = bst.min()
print(value)
print()

# leaf_count
print("leaf_count")
count = bst.leaf_count()
print(count)
print()

# one_child_count
print("one_child_count")
count = bst.one_child_count()
print(count)
print()

# two_child_count
print("two_child_count")
count = bst.two_child_count()
print(count)
print()

# inorder
print("inorder")
a = bst.inorder()
print(a)
print()

# preorder
print("preorder")
a = bst.preorder()
print(a)
print()

# postorder
print("postorder")
a = bst.postorder()
print(a)
print()

# levelorder
print("levelorder")
values = bst.levelorder()
print(values)
print()

# remove
print("remove")
key = 88
value = bst.remove(key)
print(value)
print()
