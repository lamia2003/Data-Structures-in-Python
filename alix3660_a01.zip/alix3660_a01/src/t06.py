"""
-------------------------------------------------------
t06
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-11"
-------------------------------------------------------
"""
# Import
from functions import max_diff

# Given Input
a = str(input("Enter: "))

# Function Call
md = max_diff(a)

# Output
print(f"{md}")
