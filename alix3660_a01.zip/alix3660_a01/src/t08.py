"""
-------------------------------------------------------
t08
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-11"
-------------------------------------------------------
"""
# Imports
from functions import matrix_stats

# Given Input
a = [[0, 2, 4, 6, 8],
     [1, 3, 5, 7, 9]]
print(f"{a}")

# Function Call
small, large, total, average = matrix_stats(a)

# Output
print(f"{small}")
print(f"{large}")
print(f"{total}")
print(f"{average}")
