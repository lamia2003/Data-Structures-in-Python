"""
-------------------------------------------------------
t03
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-10"
-------------------------------------------------------
"""
# Import
from functions import file_analyze

# Input
fv = open("randomfile.txt", "r")

# Function Call
u, l, d, w, r = file_analyze(fv)

# Output
print(f"Uppercase Letters: {u}")
print(f"Lowercase Letters: {l}")
print(f"Number of digits: {d}")
print(f"Number of whitespace: {w}")
print(f"Number of Remaining: {r}")
