"""
-------------------------------------------------------
t04
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-10"
-------------------------------------------------------
"""
# Import
from functions import is_leap_year

# Input
year = int(input("Enter year: "))

# Function Call
leap_year = is_leap_year(year)

# Output
print(f"Result: {leap_year}")
