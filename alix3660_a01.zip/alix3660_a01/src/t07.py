"""
-------------------------------------------------------
t07
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-11"
-------------------------------------------------------
"""
# Imports
from functions import matrix_transpose

# Inputs
a = [[0, 2, 4, 6, 8],
     [1, 3, 5, 7, 9]]
print(f"{a}")

# Function Call
b = matrix_transpose(a)

# Output
print(f"{b}")
