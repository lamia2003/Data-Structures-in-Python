"""
-------------------------------------------------------
Functions
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-12"
-------------------------------------------------------
"""


def clean_list(values):
    """
    -------------------------------------------------------
    Removes all duplicate values from a list: values contains
    only one copy of each of its integers. The order of values
    must be preserved.
    Use: clean_list(values)
    -------------------------------------------------------
    Parameters:
        values - a list of integers (list of int)
    Returns:
        None
    -------------------------------------------------------
    """
    cleaned_list = []
    for num in values:
        if num not in cleaned_list:
            cleaned_list.append(num)
    print(f"Cleaned: {cleaned_list}")
    return


def dsmvwl(s):
    """
    -------------------------------------------------------
    Disemvowels a string. out contains all the characters in s
    that are not vowels. ('y' is not considered a vowel.) Case is preserved.
    Use: out = dsmvl(s)
    -------------------------------------------------------
    Parameters:
       s - a string (str)
    Returns:
       out - s with the vowels removed (str)
    -------------------------------------------------------
    """
    out = ""
    for letter in s:
        if letter not in ("a", "A", "e", "E", "i", "I", "o", "O", "u", "U"):
            out = out + letter
    return out


def file_analyze(fv):
    """
    -------------------------------------------------------
    Analyzes the characters in a file.
    The contents of the file must be unchanged.
    Use: u, l, d, w, r = file_analyze(fv)
    -------------------------------------------------------
    Parameters:
        fv - an already open file reference (file variable)
    Returns:
        u - the number of uppercase letters in the file (int)
        l - the number of lowercase letters in the file (int)
        d - the number of digits in the file (int)
        w - the number of whitespace characters in the file (int)
        r - the number of remaining characters in the file (int)
    -------------------------------------------------------
    """
    u = 0
    l = 0
    d = 0
    w = 0
    r = 0

    for line in fv:
        for i in line:
            if i.isdigit():
                d = d + 1
            elif i.isupper():
                u = u + 1
            elif i.islower():
                l = l + 1
            elif i.isspace():
                w = w + 1
            else:
                r = r + 1
    return u, l, d, w, r


def is_leap_year(year):
    """
    -------------------------------------------------------
    Leap year determination.
    Use: leap_year = is_leap_year(year)
    -------------------------------------------------------
    Parameters:
        year - year to determine if it is a leap year (int > 0)
    Returns:
        leap_year - True if year is a leap year, False otherwise (boolean)
    -------------------------------------------------------
    """
    leap_year = True or False
    if year % 4 == 0 and year % 100 != 0:
        leap_year = True
    elif year % 400 == 0:
        leap_year = True
    else:
        leap_year = False
    return leap_year


def is_palindrome(s):
    """
    -------------------------------------------------------
    Determines if s is a palindrome. Ignores case, spaces, and
    punctuation in s.
    Use: palindrome = is_palindrome(s)
    -------------------------------------------------------
    Parameters:
        s - a string (str)
    Returns:
        palindrome - True if s is a palindrome, False otherwise (boolean)
    -------------------------------------------------------
    """
    palindrome = True or False
    if len(s) <= 1:
        palindrome = True
    elif s[0].isalpha() == False:
        palindrome = is_palindrome(s[1:])
    elif s[-1].isalpha() == False:
        palindrome = is_palindrome(s[:-1])
    else:
        if s[0].lower() == s[-1].lower():
            palindrome = is_palindrome(s[1:-1])
        else:
            palindrome = False
    return palindrome


def max_diff(a):
    """
    -------------------------------------------------------
    Returns maximum absolute difference between adjacent values in a list.
    a must be unchanged.
    Use: md = max_diff(a)
    -------------------------------------------------------
    Parameters:
        a - a list of values (list of int)
    Returns:
        md - the largest absolute difference between adjacent
            values in a list (int)
    -------------------------------------------------------
    """
    md = 0
    if len(a) == 0:
        md = 0
    if len(a) > 0:
        for i in range(1, len(a)):
            diff = abs(a[i] - a[i - 1])
            md = max(md, diff)
    return md


def matrix_transpose(a):
    """
    -------------------------------------------------------
    Transpose the contents of matrix a.
    Use: b = matrix_transpose(a):
    -------------------------------------------------------
    Parameters:
        a - a 2D list (list of lists of ?)
    Returns:
        b - the transposed matrix (list of lists of ?)
    -------------------------------------------------------
    """
    row = len(a)
    column = len(a[0])
    b = [[0 for i in range(row)] for j in range(column)]

    for i in range(row):
        for j in range(column):
            b[j][i] = a[i][j]
    return b


def matrix_stats(a):
    """
    -------------------------------------------------------
    Determines the smallest, largest, total, and average of
    the values in the 2D list a. You may assume there is at
    least one value in a.
    a must be unchanged.
    Use: small, large, total, average = matrix_stats(a):
    -------------------------------------------------------
    Parameters:
        a - a 2D list of numbers (2D list of float)
    Returns:
        small - the smallest number in a (float)
        large - the largest number in a (float)
        total - the total of all numbers in a (float)
        average - the average of all numbers in a (float)
    -------------------------------------------------------
    """
    small = a[0][0]
    large = a[0][0]
    total = 0.0
    average = 0.0
    c = 0

    for i in a:
        for j in i:
            if j < small:
                small = j
            if j > large:
                large = j
            total = total + j
            c = c + 1
    average = total / c
    return small, large, total, average


def pig_latin(word):
    """
    -------------------------------------------------------
    Converts a word to Pig Latin. The conversion is:
    - if a word begins with a vowel, add "way" to the end of the word.
    - if the word begins with consonants, move the leading consonants to
    the end of the word and add "ay" to the end of that.
    "y" is treated as a consonant if it is the first character in the word,
    and as a vowel for anywhere else in the word.
    Preserve the case of the word - i.e. if the first character of word
    is upper-case, then the new first character should also be upper case.
    Use: pl = pig_latin(word)
    -------------------------------------------------------
    Parameters:
        word - a string to convert to Pig Latin (str)
    Returns:
        pl - the Pig Latin version of word (str)
    ------------------------------------------------------
    """
    VOWEL = ["a", "A", "i", "I", "e", "E", "o", "O", "u", "U"]
    pl = ""
    x = True
    y = True or False

    if word[0] in VOWEL:
        pl = word + "way"
    else:
        for i in word:
            if i in VOWEL:
                pl = pl + i
        y = False
        for j in word:
            if j in VOWEL:
                y = True
            if y == True and j not in VOWEL:
                pl = pl + j
        k = 0
        while k < len(word) and x == True:
            if word[k] not in VOWEL:
                pl = pl + word[k]
            else:
                x = False
            k = k + 1
        pl = pl + "ay"
        pl = pl.lower()
        if word[0].isupper() == True:
            pl = pl[0].upper() + pl[1:len(pl)]
    return pl
