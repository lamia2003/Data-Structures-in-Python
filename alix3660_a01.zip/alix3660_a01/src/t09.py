"""
-------------------------------------------------------
t09
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-12"
-------------------------------------------------------
"""
# Import
from functions import pig_latin

# Input
word = str(input("Word: "))

# Function Call
pl = pig_latin(word)

# Output
print(f"Pig-Latin: {pl}")
