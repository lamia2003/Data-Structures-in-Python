"""
-------------------------------------------------------
t05
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-10"
-------------------------------------------------------
"""
# Import
from functions import is_palindrome

# Input
s = str(input("Enter: "))

# Function Call
palindrome = is_palindrome(s)

# Output
print(f"{palindrome}")
