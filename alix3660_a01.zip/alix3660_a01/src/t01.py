"""
-------------------------------------------------------
t01
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-10"
-------------------------------------------------------
"""
# Import
from functions import clean_list

# Given Input
values = [1, 2, 0, 1, 4, 1, 1, 2, 2, 5, 4,
          3, 1, 3, 3, 4, 2, 4, 3, 1, 3, 0, 3, 0, 0]
print(f"Values: {values}")

# Function Call
clean_list(values)
