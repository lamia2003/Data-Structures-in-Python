"""
-------------------------------------------------------
t03
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-02-17"
-------------------------------------------------------
"""
# Imports
from functions import vowel_count

# Parameters
s = "count vowels"

# Function Calls
count = vowel_count(s)

# Output
print(count)
