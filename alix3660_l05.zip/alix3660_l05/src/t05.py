"""
-------------------------------------------------------
t05
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-02-18"
-------------------------------------------------------
"""
# Imports
from functions import is_palindrome

# Parameters
s = "AAa"

# Function Call
palindrome = is_palindrome(s)

# Output
print(palindrome)
