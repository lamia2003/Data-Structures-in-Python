"""
-------------------------------------------------------
t04
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-02-17"
-------------------------------------------------------
"""
# Imports
from functions import to_power

# Parameters
base = 2
power = -2

# Function Call
ans = to_power(base, power)

# Output
print(ans)
