"""
-------------------------------------------------------
t06
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-02-18"
-------------------------------------------------------
"""
# Imports
from functions import bag_to_set

# Parameters
bag = [4, 5, 3, 4, 5, 2, 2, 4]

# Function Call
new_set = bag_to_set(bag)

# Output
print(new_set)
