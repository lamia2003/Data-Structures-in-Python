"""
-------------------------------------------------------
t04
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-02-03"
-------------------------------------------------------
"""
# Imports
from functions import pq_split_key
from Priority_Queue_array import Priority_Queue

# Input
source = Priority_Queue()
source.insert(1)
source.insert(2)
source.insert(3)
source.insert(4)

key = 1

# Function Call
target1, target2 = pq_split_key(source, key)

# Output
print("Target 1:")
for i in target1:
    print(i)
print()
print("Target 2:")
for j in target2:
    print(j)
