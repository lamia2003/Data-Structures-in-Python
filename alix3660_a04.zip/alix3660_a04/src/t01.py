"""
-------------------------------------------------------
t01
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-02-03"
-------------------------------------------------------
"""
# Imports
from Queue_circular import Queue

# Input
source = Queue()

# Function Call
v = source.peek()

# Output
print(v)
