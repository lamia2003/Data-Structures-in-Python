"""
-------------------------------------------------------
t04
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-29"
-------------------------------------------------------
"""
# Imports
from Queue_array import Queue
from utilities import queue_test

# Input
a = ["poo", "poo"]
queue = Queue()

# Function Call
queue_test(a)
