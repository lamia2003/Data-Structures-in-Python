"""
-------------------------------------------------------
t05
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-29"
-------------------------------------------------------
"""
# Imports
from Priority_Queue_array import Priority_Queue

# Inputs
pq = Priority_Queue()
value = int(input("Enter value: "))

# Function Call
pq.insert(value)

# Output
for i in pq:
    print(i)
