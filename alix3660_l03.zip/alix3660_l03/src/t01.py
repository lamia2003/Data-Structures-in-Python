"""
-------------------------------------------------------
t01
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-29"
-------------------------------------------------------
"""
# Imports
from Queue_array import Queue

# Input
queue = Queue()
value = int(input("Enter data: "))

# Function Call
queue.insert(value)

# Output
for obj in queue:
    print(obj)
