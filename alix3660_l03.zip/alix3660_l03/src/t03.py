"""
-------------------------------------------------------
t03
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-29"
-------------------------------------------------------
"""
# Imports
from Queue_array import Queue

# Inputs
queue = Queue()

# Function Calls
value = queue.peek()

# Output
for obj in queue:
    print(obj)
