"""
-------------------------------------------------------
t04
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-03-25"
-------------------------------------------------------
"""
# Imports
from BST_linked import BST

bst = BST()

arr = [1, 2, 3, 4]

for value in arr:
    bst.insert(value)

zero, one, two = bst.node_counts()

print("no children: ")
print(zero)

print()
print("one child: ")
print(one)

print()
print("two children: ")
print(two)

print()
print("contains: ")
print(4 in bst)

print()
print("Parent Node: ")
print(bst.parent(2))

print()
print("Parent Node (recursion): ")
print(bst.parent_r(4))
