"""
-------------------------------------------------------
t02
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-27"
-------------------------------------------------------
"""
# Imports
from Stack_array import Stack

# Inputs
target = Stack()
source1 = Stack()
source1.push(8)
source1.push(12)
source1.push(8)
source1.push(5)
print("Source 1:")
for values in source1:
    print(values)
print()
source2 = Stack()
source2.push(14)
source2.push(9)
source2.push(7)
source2.push(1)
source2.push(6)
source2.push(3)
print("Source 2:")
for values in source2:
    print(values)

# Function Call
target.combine(source1, source2)

# Output
print()
print("Target:")
for values in target:
    print(values)
