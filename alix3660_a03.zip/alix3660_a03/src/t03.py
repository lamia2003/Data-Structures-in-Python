"""
-------------------------------------------------------
t03
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-27"
-------------------------------------------------------
"""
# Imports
from functions import stack_reverse
from Stack_array import Stack

# Inputs
source = Stack()
source.push(8)
source.push(12)
source.push(8)
source.push(5)
print(f"Original Source:")
for items in source:
    print(items)
print()

# Function Call
stack_reverse(source)

# Output
print("New Source:")
for items in source:
    print(items)
