"""
-------------------------------------------------------
functions
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-27"
-------------------------------------------------------
"""
from Stack_array import Stack


def stack_combine(source1, source2):
    """
    -------------------------------------------------------
    Combines two source stacks into a target stack.
    When finished, the contents of source1 and source2 are interlaced
    into target and source1 and source2 are empty.
    Use: target = stack_combine(source1, source2)
    -------------------------------------------------------
    Parameters:
        source1 - a stack (Stack)
        source2 - another stack (Stack)
    Returns:
        target - the contents of the source1 and source2
            are interlaced into target (Stack)
    -------------------------------------------------------
    """
    target = Stack()
    while not source1.is_empty() and not source2.is_empty():
        target.push(source1.pop())
        target.push(source2.pop())
    while not source1.is_empty():
        target.push(source1.pop())
    while not source2.is_empty():
        target.push(source2.pop())
    return target


def stack_reverse(source):
    """
    -------------------------------------------------------
    Reverses the contents of a stack.
    Use: stack_reverse(source)
    -------------------------------------------------------
    Parameters:
        source - a Stack (Stack)
    Returns:
        None
    -------------------------------------------------------
    """
    rev1 = Stack()
    while not source.is_empty():
        rev1.push(source.pop())
    rev2 = Stack()
    while not rev1.is_empty():
        rev2.push(rev1.pop())
    while not rev2.is_empty():
        source.push(rev2.pop())
    return


def is_palindrome_stack(string):
    """
    -------------------------------------------------------
    Determines if string is a palindrome. Ignores case, digits, spaces, and
    punctuation in string.
    Use: palindrome = is_palindrome_stack(string)
    -------------------------------------------------------
    Parameters:
        string - a string (str)
    Returns:
        palindrome - True if string is a palindrome, False otherwise (bool)
    -------------------------------------------------------
    """
    palindrome = True
    source = Stack()
    end = len(string) - 1
    start = 0
    add = True

    while start < len(string) and end > 0 and palindrome:
        if string[start].isalpha() and True:
            source.push(string[start].lower())
        elif string[end].isalpha() and True:
            end = end + 1
        else:
            add = True
        if end < len(string):
            if string[end].isalpha():
                if (not source.is_empty()):
                    if string[end].lower() != source.pop():
                        palindrome = False
            elif string[start].isalpha():
                add = False
                start = start - 1
        end = end - 1
        start = start + 1
    return palindrome


def reroute(opstring, values_in):
    """
    -------------------------------------------------------
    Reroutes values in a list according to a operating string and
    returns a new list of values. values_in is unchanged.
    In opstring, 'S' means push onto stack,
    'X' means pop from stack into values_out.
    Use: values_out = reroute(opstring, values_in)
    -------------------------------------------------------
    Parameters:
        opstring - String containing only 'S' and 'X's (str)
        values_in - A valid list (list of ?)
    Returns:
        values_out - if opstring is valid then values_out contains a
            reordered version of values_in, otherwise returns
            None (list of ?)
    -------------------------------------------------------
    """
    source = Stack()
    values_out = []
    count1 = 0
    count2 = 0
    cont = True
    while count1 < len(opstring) and cont and count2 <= len(values_in):
        if opstring[count1] == "S" and count2 < len(values_in):
            source.push(values_in[count2])
            count2 = count2 + 1
        elif opstring[count1] == "X":
            if source.is_empty():
                cont = False
                values_out = None
            else:
                values_out.append(source.pop())
        count1 = count1 + 1
    if not source.is_empty():
        values_out = None
    elif count1 < len(opstring) - 1:
        values_out = None
    elif count2 < len(values_in) - 1:
        values_out = None
    return values_out
