"""
-------------------------------------------------------
t06
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-27"
-------------------------------------------------------
"""
# Imports
from functions import reroute

# Input
opstring = input(str("Enter a string containing only 'S' and 'X': "))
values_in = [1, 2, 3, 4, 5, 6, 7, 8]

# Function Call
values_out = reroute(opstring, values_in)

# Output
print(values_out)
