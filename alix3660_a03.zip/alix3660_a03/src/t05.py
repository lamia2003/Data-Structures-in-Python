"""
-------------------------------------------------------
t05
-------------------------------------------------------
Author:  Lamia Ali
ID:      210263660
Email:   alix3660@mylaurier.ca
__updated__ = "2022-01-27"
-------------------------------------------------------
"""
# Imports
from functions import is_palindrome_stack

# Inputs
string = input(str("Enter a string: "))

# Function Call
palindrome = is_palindrome_stack(string)

# Output
print(palindrome)
